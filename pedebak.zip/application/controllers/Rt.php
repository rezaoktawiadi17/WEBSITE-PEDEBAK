<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rt extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Admin_model', 'admo');
		$this->load->model('rt_model', 'kemo');

		$this->admo->checkLoginAdmin();
	}

	public function index()
	{
		$data['dataUser']	= $this->admo->getDataUserAdmin();
		$data['title']  	= 'rt';
		$data['rt']	= $this->kemo->getrt();
		$this->load->view('templates/header-admin', $data);
		$this->load->view('rt/index', $data);
		$this->load->view('templates/footer-admin', $data);
	}

	public function addrt()
	{
		$data['dataUser']	= $this->admo->getDataUserAdmin();
		$data['title'] 		= 'Tambah rt';

		$this->form_validation->set_rules('rt', 'rt', 'required|trim');
		if ($this->form_validation->run() == false) {
		    $this->load->view('templates/header-admin', $data);
		    $this->load->view('rt/add_rt', $data);
		    $this->load->view('templates/footer-admin', $data);  
		} else {
		    $this->kemo->addrt();
		}
	}

	public function editrt($id_rt)
	{
		$data['dataUser']	= $this->admo->getDataUserAdmin();
		$data['rt']	= $this->kemo->getrtById($id_rt);
		$data['title'] 		= 'Ubah rt - ' . $data['rt']['rt'];

		$this->form_validation->set_rules('rt', 'rt', 'required|trim');
		if ($this->form_validation->run() == false) {
		    $this->load->view('templates/header-admin', $data);
		    $this->load->view('rt/edit_rt', $data);
		    $this->load->view('templates/footer-admin', $data);  
		} else {
		    $this->kemo->editrt($id_rt);
		}
	}

	public function removert($id_rt)
	{
		$data['dataUser']	= $this->admo->getDataUserAdmin();
		$this->kemo->removert($id_rt);
	}
}
