<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rw extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Admin_model', 'admo');
		$this->load->model('rw_model', 'kelmo');
		$this->load->model('rt_model', 'kemo');

		$this->admo->checkLoginAdmin();
	}

	public function index()
	{
		$data['dataUser']	= $this->admo->getDataUserAdmin();
		$data['title']  	= 'rw';
		$data['rw']	= $this->kelmo->getrw();

		$this->load->view('templates/header-admin', $data);
		$this->load->view('rw/index', $data);
		$this->load->view('templates/footer-admin', $data);
	}

	public function addrw()
	{
		$data['dataUser']	= $this->admo->getDataUserAdmin();
		$data['title'] 		= 'Tambah rw';
		$data['rt']	= $this->kemo->getrt();

		$this->form_validation->set_rules('id_rt', 'rt', 'required|trim');
		$this->form_validation->set_rules('rw', 'rw', 'required|trim');
		if ($this->form_validation->run() == false) {
		    $this->load->view('templates/header-admin', $data);
		    $this->load->view('rw/add_rw', $data);
		    $this->load->view('templates/footer-admin', $data);  
		} else {
		    $this->kelmo->addrw();
		}
	}

	public function editrw($id_rw)
	{
		$data['dataUser']	= $this->admo->getDataUserAdmin();
		$data['rt']	= $this->kemo->getrt();
		$data['rw']	= $this->kelmo->getrwById($id_rw);
		$data['title'] 		= 'Ubah rw - ' . $data['rw']['rw'];

		$this->form_validation->set_rules('id_rt', 'rt', 'required|trim');
		$this->form_validation->set_rules('rw', 'rw', 'required|trim');
		if ($this->form_validation->run() == false) {
		    $this->load->view('templates/header-admin', $data);
		    $this->load->view('rw/edit_rw', $data);
		    $this->load->view('templates/footer-admin', $data);  
		} else {
		    $this->kelmo->editrw($id_rw);
		}
	}

	public function removerw($id_rw)
	{
		$data['dataUser']	= $this->admo->getDataUserAdmin();
		$this->kelmo->removerw($id_rw);
	}
}
