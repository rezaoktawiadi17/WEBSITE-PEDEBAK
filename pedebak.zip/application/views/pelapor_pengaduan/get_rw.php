<?php 
	$data = $_POST['data'];
	$id = $_POST['id'];
?>

<?php if($data == "rw") : ?>
	<select id="form_rw" name="id_rw">
		<?php 
			$this->db->order_by('rw', 'asc');
			$rw = $this->db->get_where('rw', ['rw.id_rt' => $id])->result_array();
		?>
		<?php foreach ($rw as $datarw): ?>
			<option value="<?= $datarw['id_rw']; ?>"><?= $datarw['rw']; ?></option>
		<?php endforeach ?>
	</select>
 
<?php endif ?>