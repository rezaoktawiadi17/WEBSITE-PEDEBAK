<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rw_model extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Admin_model', 'admo');
	}

	public function getrw()
	{
		$this->db->join('rt', 'rw.id_rt=rt.id_rt');
		$this->db->order_by('rw', 'asc');
		return $this->db->get('rw')->result_array();
	}

	public function getrwById($id_rw)
	{
		$this->db->join('rt', 'rw.id_rt=rt.id_rt');
		return $this->db->get_where('rw', ['id_rw' => $id_rw])->row_array();	
	}

	public function addrw()
	{
		$dataUser = $this->admo->getDataUserAdmin();
		$isi_log_2 = 'User ' . $dataUser['username'] . ' mencoba menambahkan rw';
		$this->admo->userPrivilege('rw', $isi_log_2);

		$data = [
			'rw'		=> ucwords(strtolower($this->input->post('rw', true))),
			'id_rt'	=> $this->input->post('id_rt', true)
		];

		$this->db->insert('rw', $data);

		$isi_log = 'rw ' . $data['rw'] . ' berhasil ditambahkan';
		$this->session->set_flashdata('message-success', $isi_log);
		redirect('rw');
	}

	public function editrw($id_rw)
	{
		$dataUser = $this->admo->getDataUserAdmin();
		$isi_log_2 = 'User ' . $dataUser['username'] . ' mencoba mengubah rw ber id ' . $id_rw;
		$this->admo->userPrivilege('rw', $isi_log_2);

		$data_rw = $this->getrwById($id_rw);
		$data = [
			'rw'		=> ucwords(strtolower($this->input->post('rw', true))),
			'id_rt'	=> $this->input->post('id_rt', true)
		];

		$this->db->update('rw', $data, ['id_rw' => $id_rw]);

		$isi_log = 'rw ' . $data['rw'] . ' berhasil diubah';
		$this->session->set_flashdata('message-success', $isi_log);
		redirect('rw');
	}

	public function removerw($id_rw)
	{
		$dataUser = $this->admo->getDataUserAdmin();
		$isi_log_2 = 'User ' . $dataUser['username'] . ' mencoba menghapus rw ber id ' . $id_rw;
		$this->admo->userPrivilege('rw', $isi_log_2);

		$data_rw = $this->getrwById($id_rw);
		$rw  = $data_rw['rw'];
		
		$this->db->delete('pengaduan', ['id_rw' => $id_rw]);
		$this->db->delete('rw', ['id_rw' => $id_rw]);
		$isi_log = 'rw ' . $rw . ' berhasil dihapus';
		$this->session->set_flashdata('message-success', $isi_log);
		redirect('rw'); 
	}
}
