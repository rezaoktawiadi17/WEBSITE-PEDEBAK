<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rt_model extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Admin_model', 'admo');
	}

	public function getrt()
	{
		$this->db->order_by('rt', 'asc');
		return $this->db->get('rt')->result_array();	
	}

	public function getrtById($id_rt)
	{
		return $this->db->get_where('rt', ['id_rt' => $id_rt])->row_array();	
	}

	public function addrt()
	{
		$dataUser = $this->admo->getDataUserAdmin();
		$this->admo->userPrivilege('rt');

		$data = [
			'rt'		=> ucwords(strtolower($this->input->post('rt', true)))
		];

		$this->db->insert('rt', $data);

		$isi_log = 'rt ' . $data['rt'] . ' berhasil ditambahkan';
		$this->session->set_flashdata('message-success', $isi_log);
		redirect('rt');
	}

	public function editrt($id_rt)
	{
		$dataUser = $this->admo->getDataUserAdmin();
		$this->admo->userPrivilege('rt');

		$data_rt = $this->getrtById($id_rt);
		$rt  = $data_rt['rt'];
		$data = [
			'rt'		=> ucwords(strtolower($this->input->post('rt', true)))
		];

		$this->db->update('rt', $data, ['id_rt' => $id_rt]);

		$isi_log = 'rt ' . $data['rt'] . ' berhasil diubah';
		$this->session->set_flashdata('message-success', $isi_log);
		redirect('rt');
	}

	public function removert($id_rt)
	{
		$dataUser = $this->admo->getDataUserAdmin();
		$isi_log_2 = 'User ' . $dataUser['username'] . ' mencoba menghapus rt ber id ' . $id_rt;
		$this->admo->userPrivilege('rt', $isi_log_2);

		$data_rt = $this->getrtById($id_rt);
		$rt  = $data_rt['rt'];
		
		$this->db->delete('rw', ['id_rt' => $id_rt]);
		$this->db->delete('rt', ['id_rt' => $id_rt]);
		$isi_log = 'rt ' . $rt . ' berhasil dihapus';
		$this->session->set_flashdata('message-success', $isi_log);
		redirect('rt'); 
	}
}